/**
 * @author K. Rege
 * @version 1.0 -- Experimentierkasten
 */
package Praktikum_01_Code;

import java.awt.*;
import java.io.*;
import java.awt.event.*;

public class ExBox {

    public static void main(String[] args) throws Exception {
        ExBoxFrame f = new ExBoxFrame();
        f.setLocationRelativeTo(null);  
        f.setVisible(true);
    }
}